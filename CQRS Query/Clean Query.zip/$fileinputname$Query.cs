﻿using MediatR;
namespace $rootnamespace$;

// Include properties to be used as input for the query
public record $itemname$() : IRequest<$fileinputname$QueryResponse>;
