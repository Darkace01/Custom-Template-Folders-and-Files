﻿using FluentValidation;

namespace $rootnamespace$;

public class $itemname$CommandValidator : AbstractValidator<$itemname$Command>
{
    public $itemname$CommandValidator()
{
    // Add validation rules here
}
}
