﻿namespace $rootnamespace$;

internal sealed class $itemname$CommandHandler: IRequestHandler<$itemname$Command, $itemname$CommandResponse>
{
    public Task<$itemname$CommandResponse> Handle($itemname$Command request, CancellationToken cancellationToken)
    {
        throw new NotImplementedException();
    }
}