﻿using MediatR;

namespace $rootnamespace$;

public record $itemname$Command() : IRequest<$itemname$CommandResponse>;