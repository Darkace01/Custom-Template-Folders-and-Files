﻿namespace $rootnamespace$;

public sealed class $itemname$CommandResponse: Response<EmptyResponse>
{
}
