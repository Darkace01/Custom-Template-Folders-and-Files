﻿namespace $rootnamespace$;

public sealed class $itemname$: Response<EmptyResponse>
{
    // Add properties and/or methods here
}
