﻿using FluentValidation;

namespace $rootnamespace$;

public class $itemname$ : AbstractValidator<$fileinputname$Command>
{
    public $itemname$()
    {
        // Add validation rules here
    }
}
