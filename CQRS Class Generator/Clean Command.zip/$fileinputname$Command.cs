﻿using MediatR;

namespace $rootnamespace$;

// Include properties to be used as input for the command
public record $itemname$() : IRequest<$fileinputname$CommandResponse>;