﻿using MediatR;

namespace $rootnamespace$;

internal sealed class $itemname$: IRequestHandler<$fileinputname$Query, $fileinputname$QueryResponse>
{
    public Task<$fileinputname$QueryResponse> Handle($fileinputname$Query request, CancellationToken cancellationToken)
    {
        // Implement your logic here
        throw new NotImplementedException();
    }
}
