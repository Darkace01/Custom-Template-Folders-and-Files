﻿namespace $rootnamespace$;

public class $itemname$: Response<EmptyResponse>
{
}
