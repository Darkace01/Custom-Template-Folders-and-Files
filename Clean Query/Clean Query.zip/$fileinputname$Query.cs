﻿using MediatR;
namespace $rootnamespace$;

public record $itemname$Query() : IRequest<$itemname$QueryResponse>;
