﻿namespace $rootnamespace$;

internal sealed class $itemname$QueryHandler: IRequestHandler<$itemname$Query, $itemname$QueryResponse>
{
    public Task<$itemname$QueryResponse> Handle($itemname$Query request, CancellationToken cancellationToken)
{
        throw new NotImplementedException();
    }
}
