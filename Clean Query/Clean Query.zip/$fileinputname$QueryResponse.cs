﻿namespace $rootnamespace$;

public class $itemname$QueryResponse: Response<EmptyResponse>
{
}
